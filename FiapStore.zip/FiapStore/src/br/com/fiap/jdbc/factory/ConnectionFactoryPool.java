package br.com.fiap.jdbc.factory;

import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

public class ConnectionFactoryPool {
	
	private static HikariDataSource dataSource;
	
	static {
		HikariConfig config = new HikariConfig();
		config.setJdbcUrl("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL");
		config.setUsername("rm552327");
		config.setPassword("240505");
		config.setMaximumPoolSize(10); //número máximo de pool (conexões sempre abertas)
		config.setMinimumIdle(5); //número mínimo de conexões ociosas
		config.setIdleTimeout(60000); //tempo em milissegundospara uma conexão ociosa ser considerada
		config.setConnectionTimeout(30000); //tempo máximo para ober uma conexão do pool
		dataSource = new HikariDataSource(config);
	}
	
	public static Connection getConnection(){
		try {
			return dataSource.getConnection();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	public static void close() {
		if(dataSource!=null) {
			dataSource.close();
		}
	}
}
