package br.com.fiap.jdbc.test;

import java.sql.SQLException;

import br.com.fiap.jdbc.controller.CategoriaController;
import br.com.fiap.jdbc.controller.ProdutoController;
import br.com.fiap.jdbc.model.Produto;

public class Teste {

	public static void main(String[] args) {
		
		
//		Produto cacau = new Produto(4, "Cacau em pó", "Cacau em pó da marca nestlé", 12.50);
//		Produto ps5 = new Produto(2, "PlayStation 5", "Console de jogos da marca Sony", 5000);
//		Produto airfryer = new Produto(3, "AirFryer", "AirFryer da marca Mondial", 350.75);
//		Produto iphone = new Produto(1, "Iphone 15", "Iphone 15 branco 128g", 7018.45);
		Produto barbie = new Produto(5, "Barbie", "Barbie artesã", 120.80);
//		Produto pacoca = new Produto(4, "Paçoca", "Paçoca tradicional paçoquita", 3.15);
//		Produto geladeira = new Produto(3, "Geladeira", "Geladeira Eletrolux branca", 3160.75);
//		Produto cod = new Produto(2, "Call of Duty", "Call of Duty Black Ops II", 137.99);
//		
		ProdutoController produtoController = new ProdutoController();
		CategoriaController categoriaController = new CategoriaController();
//		
//		produtoController.insert(cacau);
//		produtoController.insert(ps5);
//		produtoController.insert(airfryer);
//		produtoController.insert(iphone);
//		produtoController.insert(barbie);
//		produtoController.insert(pacoca);
//		produtoController.insert(geladeira);
//		produtoController.insert(cod);
		
		//System.out.println(produtoController.selectAll());
		
		//System.out.println(produtoController.selectByCategoria(2));
		
		barbie.setDescricao("Barbie - O Castelo de Diamantes");
		produtoController.update(barbie);
		System.out.println(barbie.getDescricao());
		System.out.println(produtoController.selectByCategoria(5));
		
//		produtoController.delete(3);
//		System.out.println(produtoController.selectByCategoria(4));
		
		try {
			System.out.println(categoriaController.selectByProduto());
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		try {
			System.out.println(categoriaController.selectAll());
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

}
