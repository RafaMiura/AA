package br.com.fiap.jdbc.test;

public class TestaThread extends Thread {
		
		@Override
		public void run() {
			for(int i=0; i<=5; i++) {
				System.out.println(Thread.currentThread() + "- Contador: "+ i);
				try {
					Thread.sleep(100);
				} catch (InterruptedException e){
					System.out.println("Thread interrompida");
				}
			}
		}
		
		public static void main(String[] args) {
			TestaThread thread1 = new TestaThread();
			thread1.start();
			TestaThread thread2 = new TestaThread();
			thread2.start();
			TestaThread thread3 = new TestaThread();
			thread3.start();
		}

}
