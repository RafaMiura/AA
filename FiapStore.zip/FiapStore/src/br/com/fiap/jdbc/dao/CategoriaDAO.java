package br.com.fiap.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.jdbc.model.Categoria;
import br.com.fiap.jdbc.model.Produto;

public class CategoriaDAO {

	private Connection connection;
	
	public CategoriaDAO(Connection connection) {
		this.connection = connection;
	}
	
	public void insert(Categoria categoria) {

		try {
			String sql = "insert into categorias (idCategoria, nome) values (?,?)";
			
			PreparedStatement stmt = connection.prepareStatement(sql);

			stmt.setInt(1, categoria.getIdCategoria());
			stmt.setString(2, categoria.getNome());
			stmt.execute();
			stmt.close();

		} catch (SQLException e) {
			throw new RuntimeException("Erro ao tentar executar o insert", e);
		}

	}
	
	// update
		public void update(Categoria categoria) {
			String sql = "update categorias c set c.nome=? where c.idCategoria=?";
			PreparedStatement stmt;

			try {
				stmt = connection.prepareStatement(sql);

				stmt.setString(1, categoria.getNome());
				stmt.setInt(2, categoria.getIdCategoria());

				stmt.execute();
				stmt.close();

			} catch (SQLException e) {
				throw new RuntimeException("Erro ao tentar executar o update", e);
			}

		}

		// delete
		public void delete(int id) {
			try { 
				String sql = "delete from produtos where idCategoria=?";
				PreparedStatement stmt = connection.prepareStatement(sql);
				
				stmt.setInt(1, id);

				stmt.execute();
				stmt.close();

			} catch (SQLException e) {
				throw new RuntimeException("Erro ao tentar executar o delete", e);
			}

		}
	
	public List<Categoria> selectAll(){
		try {
			List<Categoria> categorias = new ArrayList<Categoria>();
			String sql = "select * from categorias";
			
			PreparedStatement stmt = connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();
			
			while(rs.next()){
				Categoria categoria = new Categoria();
				categoria.setIdCategoria(rs.getInt("idCategoria"));
				categoria.setNome(rs.getString("nome"));
				
				categorias.add(categoria);
			}
			
			rs.close();
			stmt.close();
			return categorias;
		}catch(SQLException e) {
			throw new RuntimeException("erro ao tentar executar o select all (categoria)", e);
		}
	}
	
	public List<Categoria> selectByProduto(){
		try {
			Categoria categoriaAtual = null;
			List<Categoria> categorias = new ArrayList<Categoria>();
			
			String sql = "select c.idCategoria, c.nome, p.idProduto, p.nome, p.descricao, p.preco, p.idProduto from categorias c inner join produtos p on c.idCategoria = p.idCategoria order by c.idcategoria";
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.execute();
			ResultSet rs = stmt.getResultSet();
			
			while(rs.next()) {
				
				if(categoriaAtual == null || !categoriaAtual.getNome().equals(rs.getString("nome"))){
					Categoria categoria = new Categoria();
					categoria.setIdCategoria(rs.getInt("idCategoria"));
					categoria.setNome(rs.getString("nome"));
					categorias.add(categoria);
					
					categoriaAtual = categoria;
				}
				
				Produto produto = new Produto();
				produto.setIdProduto(rs.getInt("idProduto"));
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
				produto.setPreco(rs.getDouble("preco"));
				produto.setIdCategoria(rs.getInt("idCategoria"));
				categoriaAtual.addProduto(produto);
			}
			
			rs.close();
			stmt.close();
			return categorias;
			
		}catch(SQLException e) {
			throw new RuntimeException("falha ao tentar executar o selectByProduto", e);
		}
	}
}
