package br.com.fiap.jdbc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import br.com.fiap.jdbc.factory.ConnectionFactory;
import br.com.fiap.jdbc.model.Categoria;
import br.com.fiap.jdbc.model.Produto;

public class ProdutoDAO {

	private Connection connection;

	
	public ProdutoDAO(Connection connection) {
		this.connection = connection;
	}

	public void insert(Produto produto) {

		try {
			String sql = "insert into produtos (nome, descricao, preco, idCategoria) values (?,?,?,?)";
			
			PreparedStatement stmt = connection.prepareStatement(sql);

			stmt.setString(1, produto.getNome());
			stmt.setString(2, produto.getDescricao());
			stmt.setDouble(3, produto.getPreco());
			stmt.setInt(4, produto.getIdCategoria());

			stmt.execute();
			stmt.close();

		} catch (SQLException e) {
			throw new RuntimeException("Erro ao tentar executar o insert", e);
		}
;
	}

	// update
	public void update(Produto produto) {
		String sql = "update produtos p set p.nome=?, p.descricao=?, p.preco=?, p.idCategoria=? where p.idProduto=?";
		PreparedStatement stmt;

		try {
			stmt = connection.prepareStatement(sql);

			stmt.setString(1, produto.getNome());
			stmt.setString(2, produto.getDescricao());
			stmt.setDouble(3, produto.getPreco());
			stmt.setInt(4, produto.getIdCategoria());
			stmt.setInt(5, produto.getIdProduto());

			stmt.execute();
			stmt.close();

		} catch (SQLException e) {
			throw new RuntimeException("Erro ao tentar executar o update", e);
		}

	}

	// delete
	public void delete(int id) {
		try { 
			String sql = "delete from produtos where idProduto=?";
			PreparedStatement stmt = connection.prepareStatement(sql);
			
			stmt.setInt(1, id);

			stmt.execute();
			stmt.close();

		} catch (SQLException e) {
			throw new RuntimeException("Erro ao tentar executar o delete", e);
		}

	}

	// select all
	public List<Produto> selectAll() {
		List<Produto> produtos = new ArrayList<Produto>();

		try {
			String sql = "select * from produtos";
			PreparedStatement stmt = this.connection.prepareStatement(sql);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Produto produto = new Produto();
				produto.setIdProduto(rs.getInt("idProduto"));
				produto.setNome(rs.getString("nome"));
				produto.setDescricao(rs.getString("descricao"));
				produto.setPreco(rs.getDouble("preco"));
				produto.setIdCategoria(rs.getInt("idCategoria"));

				produtos.add(produto);
			}
			rs.close();
			stmt.close();
			return produtos;
		} catch (SQLException e) {
			throw new RuntimeException("Erro ao tentar executar select all", e);
		}

	}

	// select by id
	public List<Produto> selectByCategoria(int idCategoria) {
		List<Produto> produtos = new ArrayList<Produto>();

		try {
			String sql = "select * from produtos where idCategoria = ?";
			
			PreparedStatement stmt = connection.prepareStatement(sql);
			stmt.setInt(1, idCategoria);
			
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				Produto produto = new Produto();
				produto.setIdProduto(rs.getInt(1));
				produto.setNome(rs.getString(2));
				produto.setDescricao(rs.getString(3));
				produto.setPreco(rs.getDouble(4));
				produto.setIdCategoria(rs.getInt(5));

				produtos.add(produto);
			}
			
			rs.close();
			return produtos;
			
		}catch (SQLException e){
			throw new RuntimeException("Erro ao tentar executar select by categoria", e);
		}

	}
}