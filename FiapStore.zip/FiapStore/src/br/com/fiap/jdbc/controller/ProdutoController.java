package br.com.fiap.jdbc.controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.fiap.jdbc.dao.ProdutoDAO;
import br.com.fiap.jdbc.factory.ConnectionFactoryPool;
import br.com.fiap.jdbc.model.Produto;

public class ProdutoController {

	private ProdutoDAO produtoDAO;

	public ProdutoController(){
		Connection connection = ConnectionFactoryPool.getConnection();
		this.produtoDAO = new ProdutoDAO(connection);
	}
	
	public void insert(Produto produto) {
		this.produtoDAO.insert(produto);
	}
	
	public List<Produto> selectAll(){
		return this.produtoDAO.selectAll();
	}
	
	public List<Produto> selectByCategoria(int idCategoria){
		return this.produtoDAO.selectByCategoria(idCategoria);
	}
	
	public void update(Produto produto) {
		this.produtoDAO.update(produto);
	}
	
	public void delete(int idProduto) {
		this.produtoDAO.delete(idProduto);
	}
	
}
