package br.com.fiap.jdbc.controller;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import br.com.fiap.jdbc.dao.CategoriaDAO;
import br.com.fiap.jdbc.factory.ConnectionFactoryPool;
import br.com.fiap.jdbc.model.Categoria;

public class CategoriaController {

	private CategoriaDAO categoriaDAO;
	
	public CategoriaController(){
		Connection connection = ConnectionFactoryPool.getConnection();
		categoriaDAO = new CategoriaDAO(connection);
	}
	
	public List<Categoria> selectAll() throws SQLException{
		return this.categoriaDAO.selectAll();
	}
	
	public List<Categoria> selectByProduto() throws SQLException{
		return this.categoriaDAO.selectByProduto();
	}
}
