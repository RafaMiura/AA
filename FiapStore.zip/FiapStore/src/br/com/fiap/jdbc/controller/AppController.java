package br.com.fiap.jdbc.controller;

import java.sql.Connection;
import java.sql.SQLException;

import br.com.fiap.jdbc.dao.CategoriaDAO;
import br.com.fiap.jdbc.dao.MarcaDAO;
import br.com.fiap.jdbc.dao.ProdutoDAO;
import br.com.fiap.jdbc.dao.UsuarioDAO;
import br.com.fiap.jdbc.factory.ConnectionFactoryPool;

public class AppController {

	private static AppController instance;
	private Connection connection; 
	private UsuarioDAO usuarioDAO;
	private ProdutoDAO produtoDAO;
	private MarcaDAO marcaDAO;
	private CategoriaDAO categoriaDAO;

	
	
	
	private AppController() throws SQLException {
	this.connection = ConnectionFactoryPool.getConnection(); //obtem a conexão dis
	this.usuarioDAO = new UsuarioDAO();
	this.produtoDAO = new ProdutoDAO(connection);
	this.marcaDAO = new MarcaDAO(connection);
	this.categoriaDAO = new CategoriaDAO(connection);
} 

	//Método para obter a instancia única do AppController
	public static AppController getInstance() throws SQLException {
		if(instance == null) {
			instance = new AppController();
		}
	return instance;
	}
	
	public void closeConnection() throws SQLException {
	if(connection !=null && !connection.isClosed()) {
		connection.close();
	}
	
		}
	}
	
	
	
	
		
	

